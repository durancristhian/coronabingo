const nextTranslate = require('next-translate-plugin')
module.exports = nextTranslate({
  agentRules: false,
  images: { disableStaticImages: true },
  productionBrowserSourceMaps: true,
  webpack(config) {
    config.module.rules.push(
      { test: /\.(png|svg|mp3)$/, type: 'asset', parser: { dataUrlCondition: { maxSize: 8192 } } },
      { test: /\.md$/, type: 'asset/source' },
    )
    return config
  },
})
