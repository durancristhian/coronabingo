import useTranslation from 'next-translate/useTranslation'
import {useRouter} from 'next/router'
export default function Probe() {
  const {t,lang}=useTranslation(); const router=useRouter()
  return <main><h1>Translation compatibility probe</h1><label>Language<select aria-label="language" value={lang} onChange={e=>router.push({pathname:router.pathname,query:router.query},router.asPath,{locale:e.target.value})}><option value="es">Español</option><option value="en">English</option></select></label><p>{t('index:intro')}</p><p>{t('roomId:people',{count:1})}</p><p>{t('roomId:people',{count:2})}</p><p>Room: {router.query.roomId || 'home'}</p></main>
}
