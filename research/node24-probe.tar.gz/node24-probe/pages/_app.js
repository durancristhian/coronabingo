import '../../../public/css/styles.css'
import App from 'next/app'
export default class ProbeApp extends App { render() { const {Component,pageProps}=this.props; return <Component {...pageProps}/> } }
